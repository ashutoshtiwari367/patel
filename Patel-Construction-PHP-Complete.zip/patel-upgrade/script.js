const header=document.getElementById("header");
window.addEventListener("scroll",()=>header?.classList.toggle("scrolled",window.scrollY>20));
const menu=document.querySelector(".menu-toggle");const links=document.querySelector(".nav-links");
menu?.addEventListener("click",()=>links?.classList.toggle("open"));
document.querySelectorAll(".nav-links a").forEach(a=>a.addEventListener("click",()=>links?.classList.remove("open")));
const sections=[...document.querySelectorAll("main section[id]")];const navItems=[...document.querySelectorAll(".nav-links a")];
if(window.IntersectionObserver){const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting)navItems.forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+entry.target.id));}),{rootMargin:"-35% 0px -55% 0px"});sections.forEach(s=>observer.observe(s));}
