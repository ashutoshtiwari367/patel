<?php
// Production: move these values to environment variables or a protected config file.
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3307');
define('DB_NAME', 'patel_construction');
define('DB_USER', 'root');
define('DB_PASS', '');

define('SITE_NAME', 'Patel Construction');
define('ADMIN_EMAIL', 'info@patelconstruction.com'); // Change to real receiving email.

define('SMTP_HOST', 'smtp.example.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'info@patelconstruction.com');
define('SMTP_PASSWORD', 'CHANGE_THIS_SMTP_PASSWORD');
define('SMTP_ENCRYPTION', 'tls');
define('SMTP_FROM_EMAIL', 'info@patelconstruction.com');
define('SMTP_FROM_NAME', 'Patel Construction');
