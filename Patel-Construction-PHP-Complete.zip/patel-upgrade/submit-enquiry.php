<?php
session_start();
require_once __DIR__ . '/config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.html'); exit; }
if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) exit('Invalid request.');

$name = trim($_POST['name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');
$service = trim($_POST['service'] ?? '');
$message = trim($_POST['message'] ?? '');
$answer = (int)($_POST['captcha_answer'] ?? -999);
$expected = (int)($_SESSION['captcha_a'] ?? 0) + (int)($_SESSION['captcha_b'] ?? 0);

if ($name === '' || $phone === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $message === '' || $answer !== $expected) {
    exit('Please fill all required fields correctly and solve the CAPTCHA.');
}

$stmt = $db->prepare('INSERT INTO enquiries (name, phone, email, service, message, status, ip_address, created_at) VALUES (?, ?, ?, ?, ?, "new", ?, NOW())');
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
$stmt->bind_param('ssssss', $name, $phone, $email, $service, $message, $ip);
$stmt->execute();

// PHPMailer: Composer is preferred. Manual PHPMailer/src/ is also supported.
$autoload = __DIR__ . '/vendor/autoload.php';
if (!file_exists($autoload)) $autoload = __DIR__ . '/PHPMailer/vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
} else {
    foreach ([__DIR__.'/PHPMailer/src/Exception.php', __DIR__.'/PHPMailer/src/PHPMailer.php', __DIR__.'/PHPMailer/src/SMTP.php'] as $file) { if (file_exists($file)) require_once $file; }
}

if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_ENCRYPTION;
        $mail->Port = SMTP_PORT;
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress(ADMIN_EMAIL, SITE_NAME);
        $mail->addReplyTo($email, $name);
        $mail->isHTML(true);
        $mail->Subject = 'New Website Enquiry - ' . $name;
        $mail->Body = '<h2>New Website Enquiry</h2><p><b>Name:</b> '.htmlspecialchars($name).'</p><p><b>Phone:</b> '.htmlspecialchars($phone).'</p><p><b>Email:</b> '.htmlspecialchars($email).'</p><p><b>Service:</b> '.htmlspecialchars($service).'</p><p><b>Message:</b><br>'.nl2br(htmlspecialchars($message)).'</p>';
        $mail->send();
    } catch (Throwable $e) { error_log('PHPMailer: '.$e->getMessage()); }
}

unset($_SESSION['captcha_a'], $_SESSION['captcha_b']);
header('Location: thank-you.php'); exit;
